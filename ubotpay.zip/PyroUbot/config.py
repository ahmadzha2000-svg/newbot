# config.py
import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "10"))

DEVS = list(map(int, os.getenv("DEVS", "1147324679").split()))

API_ID = int(os.getenv("API_ID", "38617387"))

API_HASH = os.getenv("API_HASH", "297a1438c58debb60030dd864621d0aa")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8834631098:AAG7gwPTd9nlApKMQuh5lEL27DRdps83wtk")

OWNER_ID = int(os.getenv("OWNER_ID", "1147324679"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1003775292291").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://blablabla:QDHkp01r7tph2ReA@ubotnya.1h39kpd.mongodb.net/?appName=ubotnya")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1003775292291"))

# ==================== KONFIGURASI PAYMENT GATEWAY ====================

# PAKASIR PAYMENT GATEWAY
PAKASIR_API_KEY = os.getenv("PAKASIR_API_KEY", "xxx123")  # Ganti dengan API Key dari dashboard Pakasir
PAKASIR_PROJECT = os.getenv("PAKASIR_PROJECT", "depodomain")  # Nama project di Pakasir
PAKASIR_BASE_URL = os.getenv("PAKASIR_BASE_URL", "https://app.pakasir.com/api")

# HARGA PER BULAN (dalam Rupiah)
HARGA_PER_BULAN = int(os.getenv("HARGA_PER_BULAN", "10000"))  # Rp 10.000 per bulan

# MAKSIMAL BULAN PEMBELIAN
MAX_BULAN = int(os.getenv("MAX_BULAN", "12"))

# MATA UANG
CURRENCY = os.getenv("CURRENCY", "IDR")

# ==================== END KONFIGURASI PAYMENT ====================