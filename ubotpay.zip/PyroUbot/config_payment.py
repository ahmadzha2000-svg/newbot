# config_payment.py
from PyroUbot import *

# Konfigurasi Pakasir Payment Gateway
PAKASIR_CONFIG = {
    "api_key": "xxx123",  # Ganti dengan API key Anda dari Pakasir
    "project": "depodomain",
    "base_url": "https://app.pakasir.com/api",
}

# Harga per bulan dalam Rupiah
HARGA_PER_BULAN = 10000  # Rp 10.000

# Batas maksimal bulan pembelian
MAX_BULAN = 12

# Pesan pembayaran
PAYMENT_MESSAGE = """
<b>💳 PEMBAYARAN PREMIUM USERBOT</b>

<b>📋 Detail:</b>
• Harga per bulan: Rp {harga_per_bulan:,}
• Total bulan: {bulan}
• Total harga: Rp {total_harga:,}

<b>📱 Metode Pembayaran:</b>
• QRIS (Scan QR Code)
• Transfer Bank

<b>⏱️ Waktu pembayaran: 24 jam</b>

<b>💡 Setelah pembayaran, klik "Cek Status" untuk verifikasi</b>
"""