import asyncio
import json
import aiohttp
from datetime import datetime
from dateutil.relativedelta import relativedelta
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from pytz import timezone
from PyroUbot import *

# Gunakan config dari config.py
from config import (
    PAKASIR_API_KEY,
    PAKASIR_PROJECT,
    PAKASIR_BASE_URL,
    HARGA_PER_BULAN,
    MAX_BULAN,
    CURRENCY
)

CONFIRM_PAYMENT = []

@PY.CALLBACK("^(kurang|tambah)")
async def _(client, callback_query):
    """Handler untuk tombol kurang/tambah bulan"""
    data = callback_query.data.split()
    BULAN = int(data[1])
    QUERY = data[0]
    user_id = callback_query.from_user.id
    
    try:
        if QUERY == "kurang":
            if BULAN > 1:
                BULAN -= 1
        elif QUERY == "tambah":
            if BULAN < MAX_BULAN:
                BULAN += 1
        
        TOTAL_HARGA = HARGA_PER_BULAN * BULAN
        BTN.CONFIRM_PAYMENT = [
            [InlineKeyboardButton("💳 Konfirmasi Pembayaran", callback_data="confirm_payment")]
        ]
        buttons = BTN.PLUS_MINUS(BULAN, user_id)
        
        await callback_query.message.edit_text(
            MSG.TEXT_PAYMENT(HARGA_PER_BULAN, TOTAL_HARGA, BULAN),
            disable_web_page_preview=True,
            reply_markup=InlineKeyboardMarkup(buttons),
        )
    except Exception as e:
        print(f"Error in kurang/tambah: {e}")


@PY.CALLBACK("confirm_payment")
async def _(client, callback_query):
    """Handler untuk konfirmasi pembayaran"""
    data = callback_query.data.split()
    user_id = int(data[1])
    bulan = int(data[2])
    total_harga = HARGA_PER_BULAN * bulan
    
    # Buat order ID unik
    order_id = f"UBOT-{user_id}-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    # Simpan session
    PAYMENT_SESSIONS[user_id] = {
        "order_id": order_id,
        "bulan": bulan,
        "total_harga": total_harga,
        "user_id": user_id
    }
    
    # Buat transaksi di Pakasir
    success, result = await create_pakasir_transaction(
        order_id=order_id,
        amount=total_harga,
        user_id=user_id
    )
    
    if not success:
        buttons = [
            [InlineKeyboardButton("🔄 Coba Lagi", callback_data="bayar_dulu")],
            [InlineKeyboardButton("🏠 Home", callback_data=f"home {user_id}")],
        ]
        return await callback_query.edit_message_text(
            f"<b>❌ Gagal membuat transaksi: {result}</b>",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
    
    # Simpan transaksi aktif
    ACTIVE_TRANSACTIONS[order_id] = {
        "user_id": user_id,
        "bulan": bulan,
        "amount": total_harga,
        "status": "pending"
    }
    
    qr_url = result.get("qr_url")
    payment_link = result.get("payment_link")
    
    buttons = [
        [InlineKeyboardButton("💳 Bayar Sekarang", url=payment_link)],
        [InlineKeyboardButton("🔄 Cek Status", callback_data=f"check_status {order_id}")],
        [InlineKeyboardButton("❌ Batalkan", callback_data=f"cancel_payment {order_id}")],
        [InlineKeyboardButton("🏠 Home", callback_data=f"home {user_id}")],
    ]
    
    await callback_query.message.delete()
    
    # Kirim pesan dengan QR Code
    if qr_url:
        await bot.send_photo(
            user_id,
            qr_url,
            caption=f"""
<b>💳 PEMBAYARAN QRIS</b>

<b>Order ID:</b> <code>{order_id}</code>
<b>Total:</b> Rp {total_harga:,}
<b>Bulan:</b> {bulan} bulan
<b>Status:</b> ⏳ Menunggu Pembayaran

<b>📱 Scan QR Code atau klik tombol di bawah untuk membayar</b>
""",
            reply_markup=InlineKeyboardMarkup(buttons)
        )
    else:
        await bot.send_message(
            user_id,
            f"""
<b>💳 PEMBAYARAN</b>

<b>Order ID:</b> <code>{order_id}</code>
<b>Total:</b> Rp {total_harga:,}
<b>Bulan:</b> {bulan} bulan
<b>Status:</b> ⏳ Menunggu Pembayaran

<b>🔗 Link Pembayaran:</b> {payment_link}

<b>💡 Setelah pembayaran selesai, klik "Cek Status" untuk verifikasi</b>
""",
            reply_markup=InlineKeyboardMarkup(buttons)
        )


@PY.CALLBACK("check_status")
async def _(client, callback_query):
    """Handler untuk cek status pembayaran"""
    data = callback_query.data.split()
    order_id = data[1]
    user_id = callback_query.from_user.id
    
    # Ambil transaksi
    transaction = ACTIVE_TRANSACTIONS.get(order_id)
    if not transaction:
        return await callback_query.answer("❌ Transaksi tidak ditemukan", True)
    
    # Cek status ke Pakasir
    success, result = await check_pakasir_transaction(order_id)
    
    if not success:
        return await callback_query.answer(f"❌ Gagal cek status: {result}", True)
    
    status = result.get("status", "pending")
    
    if status == "paid":
        # Pembayaran berhasil
        return await process_successful_payment(callback_query, order_id, transaction)
    elif status == "expired":
        return await callback_query.edit_message_text(
            f"""
<b>❌ Transaksi telah kadaluarsa</b>

<b>Order ID:</b> <code>{order_id}</code>
<b>Status:</b> ⏰ Expired

<b>Silahkan lakukan pembayaran ulang</b>
""",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("💳 Bayar Ulang", callback_data="bayar_dulu")],
                [InlineKeyboardButton("🏠 Home", callback_data=f"home {user_id}")],
            ])
        )
    else:
        # Masih pending
        buttons = [
            [InlineKeyboardButton("🔄 Cek Lagi", callback_data=f"check_status {order_id}")],
            [InlineKeyboardButton("❌ Batalkan", callback_data=f"cancel_payment {order_id}")],
            [InlineKeyboardButton("🏠 Home", callback_data=f"home {user_id}")],
        ]
        await callback_query.answer("⏳ Pembayaran masih pending, silahkan tunggu", True)
        return await callback_query.edit_message_text(
            f"""
<b>⏳ MENUNGGU PEMBAYARAN</b>

<b>Order ID:</b> <code>{order_id}</code>
<b>Status:</b> ⏳ Menunggu Pembayaran

<b>💡 Silahkan selesaikan pembayaran Anda</b>
""",
            reply_markup=InlineKeyboardMarkup(buttons)
        )


@PY.CALLBACK("cancel_payment")
async def _(client, callback_query):
    """Handler untuk membatalkan pembayaran"""
    data = callback_query.data.split()
    order_id = data[1]
    user_id = callback_query.from_user.id
    
    transaction = ACTIVE_TRANSACTIONS.get(order_id)
    if transaction:
        # Batalkan transaksi di Pakasir
        await cancel_pakasir_transaction(
            order_id=order_id,
            amount=transaction["amount"]
        )
        ACTIVE_TRANSACTIONS.pop(order_id, None)
    
    buttons = [
        [InlineKeyboardButton("💳 Bayar Ulang", callback_data="bayar_dulu")],
        [InlineKeyboardButton("🏠 Home", callback_data=f"home {user_id}")],
    ]
    
    await callback_query.edit_message_text(
        f"""
<b>❌ Pembayaran dibatalkan</b>

<b>Order ID:</b> <code>{order_id}</code>
<b>Status:</b> ❌ Dibatalkan
""",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


async def create_pakasir_transaction(order_id, amount, user_id):
    """Membuat transaksi di Pakasir"""
    url = f"{PAKASIR_BASE_URL}/transactioncreate/qris"
    
    payload = {
        "project": PAKASIR_PROJECT,
        "order_id": order_id,
        "amount": amount,
        "api_key": PAKASIR_API_KEY,
        "customer_id": str(user_id),
        "customer_name": f"User_{user_id}"
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    return True, data
                else:
                    error_text = await response.text()
                    return False, f"HTTP {response.status}: {error_text}"
    except Exception as e:
        return False, str(e)


async def check_pakasir_transaction(order_id):
    """Cek status transaksi di Pakasir"""
    url = f"{PAKASIR_BASE_URL}/transactionstatus"
    
    payload = {
        "project": PAKASIR_PROJECT,
        "order_id": order_id,
        "api_key": PAKASIR_API_KEY
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    return True, data
                else:
                    error_text = await response.text()
                    return False, f"HTTP {response.status}: {error_text}"
    except Exception as e:
        return False, str(e)


async def cancel_pakasir_transaction(order_id, amount):
    """Batalkan transaksi di Pakasir"""
    url = f"{PAKASIR_BASE_URL}/transactioncancel"
    
    payload = {
        "project": PAKASIR_PROJECT,
        "order_id": order_id,
        "amount": amount,
        "api_key": PAKASIR_API_KEY
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, timeout=30) as response:
                return response.status == 200
    except Exception:
        return False


async def process_successful_payment(callback_query, order_id, transaction):
    """Proses pembayaran yang berhasil"""
    user_id = transaction["user_id"]
    bulan = transaction["bulan"]
    
    # Hapus transaksi dari daftar aktif
    ACTIVE_TRANSACTIONS.pop(order_id, None)
    
    # Tambahkan ke premium
    now = datetime.now(timezone("Asia/Jakarta"))
    expired = now + relativedelta(months=bulan)
    await set_expired_date(user_id, expired)
    await add_to_vars(callback_query.from_user.id, "PREM_USERS", user_id)
    
    buttons = [
        [InlineKeyboardButton("🔥 Buat Userbot 🔥", callback_data="buat_ubot")],
        [InlineKeyboardButton("🏠 Home", callback_data=f"home {user_id}")],
    ]
    
    await callback_query.edit_message_text(
        f"""
<blockquote><b>✅ PEMBAYARAN BERHASIL!</b>

<b>🎉 Selamat! Userbot Anda telah diaktifkan</b>

<b>📋 Detail:</b>
• Order ID: <code>{order_id}</code>
• Durasi: {bulan} bulan
• Berlaku hingga: {expired.strftime('%d-%m-%Y %H:%M')} WIB

<b>💡 Sekarang Anda bisa membuat userbot</b></blockquote>
""",
        reply_markup=InlineKeyboardMarkup(buttons)
    )
    
    # Notifikasi ke owner
    await bot.send_message(
        OWNER_ID,
        f"""
<b>✅ Pembayaran Berhasil!</b>

<b>User:</b> <a href=tg://user?id={user_id}>User {user_id}</a>
<b>Order ID:</b> <code>{order_id}</code>
<b>Durasi:</b> {bulan} bulan
<b>Total:</b> Rp {transaction['amount']:,}
"""
    )
    