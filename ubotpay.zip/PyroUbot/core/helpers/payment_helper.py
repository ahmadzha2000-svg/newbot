# payment_helpers.py
import json
import aiohttp
from datetime import datetime
from PyroUbot import *

async def create_transaction(user_id, bulan, total_harga):
    """Membuat transaksi baru"""
    order_id = f"UBOT-{user_id}-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    url = f"{PAKASIR_CONFIG['base_url']}/transactioncreate/qris"
    payload = {
        "project": PAKASIR_CONFIG['project'],
        "order_id": order_id,
        "amount": total_harga,
        "api_key": PAKASIR_CONFIG['api_key'],
        "customer_id": str(user_id),
        "customer_name": f"User_{user_id}"
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    return True, data
                return False, f"HTTP {response.status}"
    except Exception as e:
        return False, str(e)

async def check_transaction(order_id):
    """Cek status transaksi"""
    url = f"{PAKASIR_CONFIG['base_url']}/transactionstatus"
    payload = {
        "project": PAKASIR_CONFIG['project'],
        "order_id": order_id,
        "api_key": PAKASIR_CONFIG['api_key']
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, timeout=30) as response:
                if response.status == 200:
                    data = await response.json()
                    return True, data
                return False, f"HTTP {response.status}"
    except Exception as e:
        return False, str(e)

async def cancel_transaction(order_id, amount):
    """Batalkan transaksi"""
    url = f"{PAKASIR_CONFIG['base_url']}/transactioncancel"
    payload = {
        "project": PAKASIR_CONFIG['project'],
        "order_id": order_id,
        "amount": amount,
        "api_key": PAKASIR_CONFIG['api_key']
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, timeout=30) as response:
                return response.status == 200
    except Exception:
        return False

async def process_payment_success(user_id, bulan, order_id):
    """Proses setelah pembayaran berhasil"""
    now = datetime.now(timezone("Asia/Jakarta"))
    expired = now + relativedelta(months=bulan)
    
    await set_expired_date(user_id, expired)
    await add_to_vars(OWNER_ID, "PREM_USERS", user_id)
    
    return expired